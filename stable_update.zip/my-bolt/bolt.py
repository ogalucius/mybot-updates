# =====================================================
# SECURE COMMERCIAL AUTO-UPDATE ENGINE WITH GUI & LICENSE
# Production-Ready Version for Paid Bots/Tools
# =====================================================

import os
import sys
import shutil
import zipfile
import tempfile
import hashlib
import logging
import requests
from packaging import version
import tkinter as tk
from tkinter import messagebox, ttk

# =============================
# CONFIGURATION
# =============================
APP_NAME = "MyBot"
CURRENT_VERSION = "1.0.0"
UPDATE_CHANNEL = "stable"  # stable / beta / dev
LICENSE_KEY = "YOUR_LICENSE_KEY"  # user license to validate

BASE_URL = "https://raw.githubusercontent.com/USERNAME/YOURREPO/main/"
VERSION_URL = f"{BASE_URL}{UPDATE_CHANNEL}_version.txt"
UPDATE_ZIP_URL = f"{BASE_URL}{UPDATE_CHANNEL}_update.zip"
HASH_URL = f"{BASE_URL}{UPDATE_CHANNEL}_hash.txt"
# contains valid keys, one per line
LICENSE_URL = f"{BASE_URL}valid_licenses.txt"

BACKUP_DIR = "_backup"
LOG_FILE = "update.log"

# =============================
# LOGGING SETUP
# =============================
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# =============================
# GUI SETUP
# =============================
root = tk.Tk()
root.title(f"{APP_NAME} Updater")
root.geometry("400x200")
root.resizable(False, False)
status_label = tk.Label(root, text="Starting updater...", font=("Arial", 12))
status_label.pack(pady=20)
progress = ttk.Progressbar(root, orient=tk.HORIZONTAL,
                           length=300, mode='determinate')
progress.pack(pady=10)
root.update()

# =============================
# HELPER FUNCTIONS
# =============================


def log(msg):
    print(msg)
    logging.info(msg)
    status_label.config(text=msg)
    root.update()


def get_remote_text(url):
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    return r.text.strip()


def download_file(url, dest):
    log(f"Downloading update...")
    r = requests.get(url, stream=True, timeout=30)
    r.raise_for_status()
    total = int(r.headers.get('content-length', 0))
    downloaded = 0
    with open(dest, "wb") as f:
        for chunk in r.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    progress['value'] = (downloaded / total) * 100
                    root.update()


def calculate_sha256(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha256.update(chunk)
    return sha256.hexdigest()

# =============================
# BACKUP & ROLLBACK
# =============================


def create_backup():
    log("Creating backup...")
    if os.path.exists(BACKUP_DIR):
        shutil.rmtree(BACKUP_DIR)
    shutil.copytree(os.getcwd(), BACKUP_DIR, dirs_exist_ok=True)


def restore_backup():
    log("Restoring backup due to failure...")
    for item in os.listdir(BACKUP_DIR):
        src = os.path.join(BACKUP_DIR, item)
        dst = os.path.join(os.getcwd(), item)
        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

# =============================
# APPLY UPDATE
# =============================


def apply_update(zip_path):
    temp_dir = tempfile.mkdtemp()
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(temp_dir)

    for item in os.listdir(temp_dir):
        src = os.path.join(temp_dir, item)
        dst = os.path.join(os.getcwd(), item)
        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)

    shutil.rmtree(temp_dir)

# =============================
# LICENSE VALIDATION
# =============================


def validate_license():
    try:
        valid_keys = get_remote_text(LICENSE_URL).splitlines()
        if LICENSE_KEY not in valid_keys:
            log("License key invalid. Update not allowed.")
            messagebox.showerror(
                "License Error", "Invalid license key. Cannot proceed.")
            root.destroy()
            sys.exit(1)
        log("License key validated.")
    except Exception as e:
        log(f"License validation failed: {e}")
        messagebox.showerror(
            "License Error", f"License validation failed: {e}")
        root.destroy()
        sys.exit(1)

# =============================
# MAIN UPDATE LOGIC
# =============================


def check_for_updates():
    try:
        validate_license()
        log("Checking for updates...")
        remote_version = get_remote_text(VERSION_URL)

        if version.parse(remote_version) <= version.parse(CURRENT_VERSION):
            log("Already running latest version.")
            messagebox.showinfo(
                "Updater", "You are already on the latest version.")
            root.destroy()
            return False

        log(f"New version available: {remote_version}")

        # Download update
        zip_path = "update_package.zip"
        download_file(UPDATE_ZIP_URL, zip_path)

        # Verify integrity
        expected_hash = get_remote_text(HASH_URL)
        actual_hash = calculate_sha256(zip_path)

        if actual_hash != expected_hash:
            log("Hash verification failed. Aborting update.")
            messagebox.showerror("Updater", "Update file corrupted. Aborting.")
            os.remove(zip_path)
            root.destroy()
            return False

        log("Hash verified successfully.")

        # Backup current version
        create_backup()

        try:
            apply_update(zip_path)
            log("Update applied successfully.")
            messagebox.showinfo(
                "Updater", "Update applied successfully. Restarting app...")
        except Exception as e:
            log(f"Update failed: {e}")
            restore_backup()
            messagebox.showerror("Updater", f"Update failed: {e}")
            root.destroy()
            return False
        finally:
            os.remove(zip_path)

        # Restart application
        log("Restarting application...")
        root.destroy()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    except Exception as e:
        log(f"Update process failed: {e}")
        messagebox.showerror("Updater", f"Update process failed: {e}")
        root.destroy()
        return False


# =============================
# ENTRY POINT
# =============================
if __name__ == "__main__":
    check_for_updates()
    root.mainloop()
